Thronos CPU Miner Kit
=====================

Βήματα (Windows / Linux / Mac):

1. Κατεβάζεις τα αρχεία:
   - pow_miner.py
   - (προαιρετικά) start_cpu_miner.bat για Windows

2. Βρίσκεις το THR Address σου:
   - Κάνεις pledge στο https://thrchain.up.railway.app/pledge
   - Στο τέλος εμφανίζεται:
       THR Address: THRxxxxxxxxxxxxxxx

3. Ανοίγεις το pow_miner.py με έναν editor (Notepad, VSCode, κ.λπ.)
   - Στην αρχή του αρχείου θα βρεις:
       THR_ADDRESS = "THR_PUT_YOUR_ADDRESS_HERE"
   - Βάλε το δικό σου THR address ανάμεσα στα εισαγωγικά.
   - Σώσε το αρχείο.

4. Εγκαθιστάς Python 3 και requests:
   - https://www.python.org/downloads/
   - Άνοιξε terminal/Command Prompt:
       pip install requests

5. Τρέχεις το miner:
   - python pow_miner.py

6. Βλέπεις τα blocks στο Viewer:
   - https://thrchain.up.railway.app/viewer
   - Βλέπεις το balance σου στο wallet:
   - https://thrchain.up.railway.app/wallet?address=ΤΟ_THR_ΣΟΥ (ή από το UI)

Tip:
- Αν θέλεις να σταματήσεις το miner, πάτα Ctrl+C στο terminal.
