#!/usr/bin/env python3
# Thronos CPU PoW Miner (generic kit)
#
# 1. Βάλε το THR address σου στο THR_ADDRESS.
# 2. Τρέξε:  pip install requests
# 3. Τρέξε:  python pow_miner.py

import hashlib
import time
import requests


THR_ADDRESS = "THR1764439422895"

# Πόσο δύσκολο είναι το hash (αριθμός αρχικών μηδενικών στο hex)
DIFFICULTY = 4

SERVER = "https://thrchain.up.railway.app"


def get_last_hash():
    """Παίρνει το hash του τελευταίου block από το Thronos server."""
    try:
        r = requests.get(f"{SERVER}/last_block_hash", timeout=5)
        r.raise_for_status()
        return r.json().get("last_hash", "0" * 64)
    except Exception as e:
        print("❌ Failed to fetch last hash:", e)
        return "0" * 64


def mine_block():
    """
    Απλό CPU mining:
    - Παίρνει last_hash
    - Δοκιμάζει nonces μέχρι το SHA256(last_hash + thr + nonce) να έχει
      DIFFICULTY αρχικά '0'
    - Επιστρέφει το block payload έτοιμο για submit στο /submit_block
    """
    last_hash = get_last_hash()
    target_prefix = "0" * DIFFICULTY

    print(f"⛏️  Starting mining for {THR_ADDRESS} (difficulty={DIFFICULTY})")
    print(f"   Last block hash: {last_hash}")

    nonce = 0
    start = time.time()
    while True:
        nonce_str = str(nonce).encode()
        data = (last_hash + THR_ADDRESS).encode() + nonce_str
        h = hashlib.sha256(data).hexdigest()

        if nonce % 50_000 == 0:
            elapsed = time.time() - start
            print(f"[{THR_ADDRESS}] nonce={nonce} hash={h[:16]}… ({elapsed:.1f}s)")

        if h.startswith(target_prefix):
            duration = time.time() - start
            print(f"✅ Found valid nonce after {nonce} tries in {duration:.1f}s")
            print(f"   Hash: {h}")
            block = {
                "thr_address": THR_ADDRESS,
                "nonce": nonce,
                "pow_hash": h,
                "prev_hash": last_hash,
            }
            return block

        nonce += 1


def submit_block(block):
    """Στέλνει το mined block στο /submit_block."""
    try:
        r = requests.post(f"{SERVER}/submit_block", json=block, timeout=10)
        print("📬 Submission result:", r.status_code, r.json())
    except Exception as e:
        print("❌ Error submitting block:", e)


if __name__ == "__main__":
    if THR_ADDRESS == "THR_PUT_YOUR_ADDRESS_HERE":
        print("⚠️ Βάλε πρώτα το THR address σου στο THR_ADDRESS στην αρχή του αρχείου!")
        exit(1)

    while True:
        block = mine_block()
        submit_block(block)
        # μικρό delay να μη spam-άρουμε server logs
        time.sleep(5)
